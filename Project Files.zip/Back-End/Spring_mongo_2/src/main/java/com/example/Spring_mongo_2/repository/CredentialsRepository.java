package com.example.Spring_mongo_2.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.Spring_mongo_2.model.Credentials;
import com.example.Spring_mongo_2.model.User;

public interface CredentialsRepository extends MongoRepository<Credentials,User>
{
	public Credentials findByuser(User user);
	public Credentials findByemail(String email);
	public Credentials findBypassword(String password);
	
	public void deleteByuser();
	public void deleteByemail();
	public void deleteBypassword();
}
