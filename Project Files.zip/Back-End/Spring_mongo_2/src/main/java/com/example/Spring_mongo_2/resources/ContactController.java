package com.example.Spring_mongo_2.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Spring_mongo_2.model.Contact;
import com.example.Spring_mongo_2.repository.ContactRepository;
import com.example.Spring_mongo_2.repository.UserRepository;

@RestController
public class ContactController 
{
	@Autowired
	public ContactRepository contactrepository;
	
	@Autowired
	public UserRepository userrepository;
	
	@GetMapping("/findAllContact")
	public List<Contact> findAlllContact()
	{
		return contactrepository.findAll();
	}
	
	@GetMapping("/getContact")
	public List<Contact> findByph_no(String ph_no)
	{
		return contactrepository.findByphno(ph_no);
	}
	
}
