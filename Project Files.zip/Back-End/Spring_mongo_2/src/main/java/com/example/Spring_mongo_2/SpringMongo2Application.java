package com.example.Spring_mongo_2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.Spring_mongo_2.model.User;
import com.example.Spring_mongo_2.model.Contact;
import com.example.Spring_mongo_2.model.Credentials;
import com.example.Spring_mongo_2.model.userAuthority;
import com.example.Spring_mongo_2.repository.ContactRepository;
import com.example.Spring_mongo_2.repository.CredentialsRepository;
import com.example.Spring_mongo_2.repository.UserRepository;
import com.example.Spring_mongo_2.repository.userAuthorityRepository;

import java.io.*;

@SpringBootApplication
public class SpringMongo2Application implements CommandLineRunner 
{

  @Autowired
  private UserRepository userrepository;
  
  @Autowired
  private ContactRepository contactrepository;
  
  @Autowired
  private CredentialsRepository credentialsrepository;
  
  @Autowired
  private userAuthorityRepository userauthorityrepository;

  public static void main(String[] args) 
  {
	  SpringApplication.run(SpringMongo2Application.class, args);
  }

  @Override
  public void run(String... args) throws Exception 
  {

    /*userrepository.deleteAll();
    contactrepository.deleteAll();*/
   
    BufferedReader obj=new BufferedReader(new InputStreamReader(System.in));
    int selection=0;
    boolean iterate=true;
    String firstname="",lastname="",bloodtype="",address="",ph_no="",role="",email="",password="";
    
    System.out.print("Enter your email ID: ");
    email=obj.readLine();
    System.out.println("Enter the password: ");
    password=obj.readLine();
    
    User user_global=null;
    
    System.out.println(credentialsrepository.findByemail(email)!=null);
    
    if(credentialsrepository.findByemail(email)!=null && credentialsrepository.findBypassword(password)!=null)
    {
    	if (credentialsrepository.findByemail(email).user.id.equalsIgnoreCase(credentialsrepository.findBypassword(password).user.id) )
    	{
    		user_global=credentialsrepository.findByemail(email).user;
    		System.out.println("You have successfully logged in!!");
    	}
    	else
    	{
    		System.out.println("Email or Password is invalid. ");
    		
    		{
    			System.out.println("Please do retry!!");
    			//SpringApplication.run(SpringMongo2Application.class, args);
    		}
    	}
    }
    else
    {
    	System.out.println("No such login found.");
    	System.out.println("Do you want to register yourself in the website(Y/N)?");
		String choice=obj.readLine();
		
		if(choice.equalsIgnoreCase("Y"))
		{
			{
	    		System.out.print("Enter the First Name: ");
	    		firstname=obj.readLine();
	    		System.out.print("Enter the Last Name: ");
	    		lastname=obj.readLine();
	    		System.out.print("Enter the Blood Type: ");
	    		bloodtype=obj.readLine();
	    		//System.out.print("Enter the Role (a=admin, u=normal user): ");
	    		//role=obj.readLine();
	    		role="u";
	    		System.out.print("Enter the Address: ");
	    		address=obj.readLine();
	    		System.out.print("Enter the Phone Number: ");
	    		ph_no=obj.readLine();
	    		System.out.print("Enter the Email: ");
	    		email=obj.readLine();
	    		System.out.print("Enter the Password: ");
	    		password=obj.readLine();
	    		User user=new User(firstname, lastname/*,role*/,bloodtype);
	    	    userrepository.save(user);
	    	    Contact contact=new Contact(user,address,ph_no);
	    	    contactrepository.save(contact);
	    	    Credentials credentials=new Credentials(user, email, password);
	    	    credentialsrepository.save(credentials);
	    	    userAuthority userauthority=new userAuthority(user,role);
	    	    userauthorityrepository.save(userauthority);
	    	    
	    	    user_global=user;
	    	}
		}
		else
			System.exit(0);
    }
    
    while (iterate)
    {
    	
    	System.out.println("What is your next operation:");
    	System.out.println("1. Add a user");
    	System.out.println("2. Print all the users");
    	System.out.println("3. Get info on a perticular user with the first name");
    	System.out.println("4. Get info on a perticular user with the last name");
    	System.out.println("5. Get info on a perticular user with the blood type");
    	System.out.println("6. Delete the record of a user");
    	System.out.println("7. Change the role of a user");
    	System.out.println("8. Exit");
    	
    	selection=Integer.parseInt(obj.readLine());
    	
    	switch(selection)
    	{
	    	case 1:
	    		// save a couple of customers
	    		if (userauthorityrepository.findByuser(user_global).role.equalsIgnoreCase("a"))
		    	{
		    		System.out.print("Enter the first name: ");
		    		firstname=obj.readLine();
		    		System.out.print("Enter the last name: ");
		    		lastname=obj.readLine();
		    		System.out.print("Enter the blood type: ");
		    		bloodtype=obj.readLine();
		    		System.out.print("Enter the role (a=admin, u=normal user): ");
		    		role=obj.readLine();
		    		System.out.print("Enter the address: ");
		    		address=obj.readLine();
		    		System.out.print("Enter the phone number: ");
		    		ph_no=obj.readLine();
		    		User user=new User(firstname, lastname/*,role*/,bloodtype);
		    	    userrepository.save(user);
		    	    Contact contact=new Contact(user,address,ph_no);
		    	    contactrepository.save(contact);
		    	    userAuthority userauthority=new userAuthority(user,role);
		    	    userauthorityrepository.save(userauthority);
		    	    
		    	}
	    		else
	    		{
	    			System.out.println("Error: No permission to access!");
	    			System.out.println();
	    			continue;
	    		}
	    	    break;
	    	case 2:
	    		//if (user_global.role.equalsIgnoreCase("a"))
		    	{
		    		// fetch all customers
		    	    System.out.println("Customers found with findAll():");
		    	    System.out.println("-------------------------------");
		    	    for (User user : userrepository.findAll()) 
		    	    {
		    	      System.out.println(user);
		    	      System.out.println(contactrepository.findByuser(user));
		    	    }
		    	    
		    	    System.out.println();
		    	}
	    		/*else
	    		{
	    			System.out.println("Error: No permission to access!");
	    			System.out.println();
	    			continue;
	    		}*/
	    	    break;
	    	case 3:
	    		// fetch an individual customer
	    		if (userauthorityrepository.findByuser(user_global).role.equalsIgnoreCase("a"))
	    		{
	    			System.out.print("Enter the first name: ");
		    		firstname=obj.readLine();
		    	    System.out.println("Customer found with findByFirstName("+firstname+"):");
		    	    System.out.println("--------------------------------");
//		    	    System.out.println(userrepository.findByfirstName(firstname));
		    	    for (User user: userrepository.findByfirstName(firstname))
		    	    {
		    	    	System.out.println(user);
		    	    	System.out.println(contactrepository.findByuser(user));
		    	    	
		    	    }
		    	    System.out.println();
	    		}
	    		else
	    		{
	    			System.out.println("Error: No permission to access!");
	    			System.out.println();
	    			continue;
	    		}
	    	    break;
	    	case 4:
	    		if (userauthorityrepository.findByuser(user_global).role.equalsIgnoreCase("a"))
	    		{
	    			System.out.print("Enter the last name: ");
		    		lastname=obj.readLine();
		    		System.out.println("Customers found with findByLastName("+lastname+"):");
		    	    System.out.println("--------------------------------");
		    	    for (User user : userrepository.findBylastName(lastname)) 
		    	    {
		    	    	System.out.println(user);
			    	    System.out.println(contactrepository.findByuser(user));
		    	    }
	    		}
	    		else
	    		{
	    			System.out.println("Error: No permission to access!");
	    			System.out.println();
	    			continue;
	    		}
	    		break;
	    	case 5:
	    		if (userauthorityrepository.findByuser(user_global).role.equalsIgnoreCase("a"))
	    		{
	    			System.out.print("Enter the blood type: ");
	    			bloodtype=obj.readLine();
	    			System.out.println("Usrs found with the blood type: "+bloodtype);
	    		    System.out.println("--------------------------------");
	    		    for(User user: userrepository.findBybloodType(bloodtype))
	    		    {
	    		    	System.out.println(user);
   		    	        System.out.println(contactrepository.findByuser(user));
	    		    }
	    		    System.out.println();
	    		}
	    		else
	    		{
	    			System.out.println("Error: No permission to access!");
	    			System.out.println();
	    			continue;
	    		}
	    		break;
	    	case 6:
	    		if (userauthorityrepository.findByuser(user_global).role.equalsIgnoreCase("a"))
	    		{
	    			System.out.print("Enter the first name: ");
	    			firstname=obj.readLine();
	    			
	    			for (User user: userrepository.findByfirstName(firstname))
	    			{
	    				userrepository.deleteByfirstName(firstname);
		    			contactrepository.deleteByuser(user);
	    			}
	    		}
	    		else
	    		{
	    			System.out.println("Error: No permission to access!");
	    			System.out.println();
	    			continue;
	    		}
	    		break;
	    	case 7:
	    		if (userauthorityrepository.findByuser(user_global).role.equalsIgnoreCase("a"))
	    		{
	    			System.out.println("Enter your First Name: ");
	    			firstname=obj.readLine();
	    			
	    			for(User user: userrepository.findByfirstName(firstname))
	    			{
	    				System.out.println("User found: "+user);
	    				System.out.println("With the user authority: "+userauthorityrepository.findByuser(user));
	    				System.out.println("What do you want to change it to (a=admin, u=user)?: ");
	    				String role_choice=obj.readLine();
	    				userauthorityrepository.findByuser(user).setRole(role_choice);
	    				//credentialsrepository.findByuser(user).user.setRole(role_choice);
	    				//contactrepository.findByuser(user).user.setRole(role_choice);
	    			}
	    		}
	    		else
	    		{
	    			System.out.println("Error: No permission to access!");
	    			System.out.println();
	    			continue;
	    		}
	    		break;
	    	case 8:
	    		iterate=false;
	    		break;
	    	default:
	    		System.out.println("Wrong input......Please try again");
	    		continue;
    	}
    	
    }
    System.exit(0);
    
  }
  
 
}