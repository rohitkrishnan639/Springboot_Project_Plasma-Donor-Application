package com.example.Spring_mongo_2.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="plasma_collection")
public class User {

@Id
  public String id;

  public String firstName;
  public String lastName;
  public String bloodType;
  //public String role;
  //public static int id_count=0;

public User() {}

  public User(String firstName, String lastName /*,String role*/,String bloodType) {
    this.firstName = firstName;
    this.lastName = lastName;
    //this.role=role;
    this.bloodType=bloodType;
  }

  public String getBloodType() {
	return bloodType;
}

public void setBloodType(String bloodType) {
	this.bloodType = bloodType;
}
  
  public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

/*public String getRole() {
	return role;
}

public void setRole(String role) {
	this.role = role;
}*/

@Override
  public String toString() {
    return String.format(
        "User Info[id=%s, firstName='%s', lastName='%s', bloodType='%s']",
        id, firstName, lastName/*,role*/,bloodType);
  }


}