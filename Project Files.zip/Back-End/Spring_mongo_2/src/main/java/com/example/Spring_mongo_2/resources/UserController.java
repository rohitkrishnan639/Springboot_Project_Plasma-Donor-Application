package com.example.Spring_mongo_2.resources;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Spring_mongo_2.model.User;
import com.example.Spring_mongo_2.repository.UserRepository;

@RestController
public class UserController 
{
	@Autowired
	public UserRepository repository;
	
	@PostMapping("/addUser")
	public  String registerUser(@RequestBody User user)
	{
		repository.save(user);
		return "User registered Successfully with id: "+user.getId();
	}
	
	@GetMapping("/findAllUsers")
	public List<User> getAllUser()
	{
		return repository.findAll();
	}
	
	@GetMapping("/findUser/{id}")
	public Optional<User> getUser(@PathVariable String id)
	{
		return repository.findById(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteUser(@PathVariable String id)
	{
		repository.deleteById(id);
		return "User deleted with id: "+id;
	}
}
