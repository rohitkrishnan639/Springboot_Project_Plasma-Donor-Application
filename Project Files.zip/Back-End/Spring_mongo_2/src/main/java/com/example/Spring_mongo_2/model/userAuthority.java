package com.example.Spring_mongo_2.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("authority_collection")
public class userAuthority 
{
	@Id
	public User user;
	
	public String role;
	
	public userAuthority(){}
	
	public userAuthority(User user,String role)
	{
		this.user=user;
		this.role=role;
	}
	
	public User getUser() 
	{
		return user;
	}

	public void setUser(User user) 
	{
		this.user = user;
	}

	public String getRole() 
	{
		return role;
	}

	public void setRole(String role) 
	{
		this.role = role;
	}
}
