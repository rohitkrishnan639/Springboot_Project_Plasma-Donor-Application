package com.example.Spring_mongo_2.resources;

public class userAuthorityController {

}
