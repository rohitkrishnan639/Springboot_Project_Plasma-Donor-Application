package com.example.Spring_mongo_2.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="address_collection")
public class Contact 
{
	@Id
	public User user;
	
	public String address;
	public String phno;
	
	public Contact() {}
	
	public Contact(User user, String address, String ph_no)
	{
		this.user=user;
		this.address=address;
		this.phno=ph_no;
	}
	public User getUser() 
	{
		return user;
	}
	public void setUser(User user) 
	{
		this.user = user;
	}
	public String getAddress() 
	{
		return address;
	}
	public void setAddress(String address) 
	{
		this.address = address;
	}
	public String getPh_no() 
	{
		return phno;
	}
	public void setPh_no(String ph_no) 
	{
		this.phno = ph_no;
	}
	
	@Override
	  public String toString() {
	    return String.format(
	        "User contact info[address='%s', phone number='%s']",
	        address,phno);
	  }
}
