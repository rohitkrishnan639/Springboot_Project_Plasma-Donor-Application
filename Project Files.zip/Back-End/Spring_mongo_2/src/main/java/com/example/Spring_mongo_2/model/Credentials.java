package com.example.Spring_mongo_2.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("credentials_collection")
public class Credentials 
{
	@Id
	public User user;
	
	private String email;
	private String password;
	
	public Credentials() {}
	
	public Credentials(User user, String email, String password) 
	{
		this.user=user;
		this.email=email;
		this.password=password;
	}
	
	public User getUser() 
	{
		return user;
	}
	public void setUser(User user) 
	{
		this.user = user;
	}
	public String getEmail() 
	{
		return email;
	}
	public void setEmail(String email) 
	{
		this.email = email;
	}
	public String getPassword() 
	{
		return password;
	}
	public void setPaassword(String password) 
	{
		this.password = password;
	}	
	
}
