package com.example.Spring_mongo_2.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.Spring_mongo_2.model.Contact;
import com.example.Spring_mongo_2.model.User;

public interface ContactRepository extends MongoRepository<Contact,User>
{
	public List<Contact> findByphno(String ph_no);
	public  Contact findByuser(User user);
	public void deleteByphno(String ph_no);
	public void deleteByuser(User user);
}
