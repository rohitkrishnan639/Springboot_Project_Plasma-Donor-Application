package com.example.Spring_mongo_2.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.Spring_mongo_2.model.User;

public interface UserRepository extends MongoRepository<User, String> {

  public List<User> findByfirstName(String firstName);
  public List<User> findBylastName(String lastName);
  public List<User> findBybloodType(String bloodType);
  public List<User> findByid(String id);
  public void deleteByid(String id);
  public void deleteByfirstName(String firstname);
  public void deleteBylastName(String lastname);
  public void deleteBybloodType(String bloodtype);
}