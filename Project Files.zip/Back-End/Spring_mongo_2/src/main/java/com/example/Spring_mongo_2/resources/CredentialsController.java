package com.example.Spring_mongo_2.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.example.Spring_mongo_2.repository.CredentialsRepository;
import com.example.Spring_mongo_2.repository.UserRepository;

@RestController
public class CredentialsController 
{
	@Autowired
	public UserRepository userrepository;
	
	@Autowired
	public CredentialsRepository credentialsrepository;
}
