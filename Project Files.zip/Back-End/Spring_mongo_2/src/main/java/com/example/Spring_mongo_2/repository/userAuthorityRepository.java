package com.example.Spring_mongo_2.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.Spring_mongo_2.model.User;
import com.example.Spring_mongo_2.model.userAuthority;

public interface userAuthorityRepository extends MongoRepository<userAuthority,User>
{
	public userAuthority findByuser(User user);
	public List<String> findByrole(String role);
	
	public void deleteByuser(User user);
	public void deleteByrole(String role);
}
