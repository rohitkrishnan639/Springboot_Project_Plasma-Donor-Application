package com.example.Spring_mongo_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMongo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
